-- MySQL dump 10.13  Distrib 5.7.37, for Linux (x86_64)
--
-- Host: localhost    Database: jichu
-- ------------------------------------------------------
-- Server version	5.7.37-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hhkj_admin`
--

DROP TABLE IF EXISTS `hhkj_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hhkj_admin` (
  `admin_id` int(2) NOT NULL AUTO_INCREMENT COMMENT '管理员id',
  `username` varchar(10) NOT NULL COMMENT '用户名',
  `password` varchar(60) NOT NULL COMMENT '密码',
  `last_login_ip` varchar(255) DEFAULT NULL COMMENT '最后登录ip',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `role_id` int(10) NOT NULL COMMENT '角色id',
  `atime` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='管理员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hhkj_admin`
--

LOCK TABLES `hhkj_admin` WRITE;
/*!40000 ALTER TABLE `hhkj_admin` DISABLE KEYS */;
INSERT INTO `hhkj_admin` VALUES (4,'admin','$2y$10$LH958.seW6XLuW0bCbsncuoR6QlKgb8MF6.1F6ZVikWEcteOiQQU2','192.168.0.87','2024-05-31 10:59:17',1,'2021-12-12 22:43:58','https://hhkj-1259388795.cos.ap-chongqing.myqcloud.com//16449780286081.png'),(6,'ceshi1','$2y$10$K.e6KZratF8cterC.k/pWON3NEbkX84.Ihc5T4jcgFJvg7/HTcJ7G','192.168.2.86','2022-02-08 15:06:42',1,'2021-08-27 00:14:47','https://qiniu.honghukeji.net/16444739833091.jpg');
/*!40000 ALTER TABLE `hhkj_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hhkj_admin_log`
--

DROP TABLE IF EXISTS `hhkj_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hhkj_admin_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `atime` datetime NOT NULL,
  `route` char(32) DEFAULT NULL,
  `desc` char(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='管理员操作日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hhkj_admin_log`
--

LOCK TABLES `hhkj_admin_log` WRITE;
/*!40000 ALTER TABLE `hhkj_admin_log` DISABLE KEYS */;
INSERT INTO `hhkj_admin_log` VALUES (1,4,'192.168.0.87','未知','2024-05-31 10:59:17','/login/login','用户登录');
/*!40000 ALTER TABLE `hhkj_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hhkj_menu`
--

DROP TABLE IF EXISTS `hhkj_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hhkj_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) DEFAULT NULL COMMENT '上级id',
  `name` varchar(64) CHARACTER SET utf8 DEFAULT NULL COMMENT '菜单名称',
  `path` varchar(64) CHARACTER SET utf8 DEFAULT NULL COMMENT '前端路由',
  `route` varchar(64) CHARACTER SET utf8 DEFAULT NULL COMMENT '后端路由',
  `level` tinyint(1) DEFAULT '1' COMMENT '菜单等级',
  `icon` varchar(32) CHARACTER SET utf8 NOT NULL COMMENT '图标',
  `sort` int(10) DEFAULT NULL COMMENT '排序 低到高',
  `needLog` tinyint(1) DEFAULT '0' COMMENT '是否需要日志',
  `display` tinyint(1) DEFAULT '1' COMMENT '是否显示',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hhkj_menu`
--

LOCK TABLES `hhkj_menu` WRITE;
/*!40000 ALTER TABLE `hhkj_menu` DISABLE KEYS */;
INSERT INTO `hhkj_menu` VALUES (1,0,'系统设置','','',1,'icon-jibenguanli',0,0,1),(2,1,'角色列表','RoleList','/admin/role/roleList',2,'',2,0,1),(5,1,'管理员列表','AdminList','/admin/admin/adminList',2,'',1,0,1),(6,5,'添加管理员','','/admin/admin/addAdmin',3,'',0,1,0),(9,2,'添加角色','','/admin/role/addRole',3,'',2,1,0),(10,2,'编辑角色','','/admin/role/editRole',3,'',3,1,0),(11,2,'删除角色','','/admin/role/delRole',3,'',4,0,0),(12,5,'编辑管理员','','/admin/admin/editAdmin',3,'',1,0,0),(13,5,'删除管理员','','/admin/admin/delAdmin',3,'',3,0,0),(14,1,'操作日志','OperationLog','/admin/admin/adminLog',2,'',5,0,1),(15,1,'菜单管理','MenuSet','/admin/menu/menuList',2,'',3,0,1),(16,15,'新增菜单','','/admin/menu/addMenu',3,'',0,0,0),(17,15,'编辑菜单','','/admin/menu/editMenu',3,'',1,0,0),(18,15,'删除菜单','','/admin/menu/delMenu',3,'',2,0,0),(19,15,'设置日志打印','','/admin/menu/setNeedLog',3,'',3,0,0),(20,1,'上传设置','UploadSet','/admin/setting/getUploadConfig',2,'',4,0,1),(21,1,'参数配置','BasicInfo','/admin/setting/settingList',2,'',2,0,1),(22,21,'新增配置','','/admin/setting/addSetting',3,'',1,0,0),(23,21,'修改配置','','/admin/setting/editSetting',3,'',3,0,0),(24,21,'删除配置','','/admin/setting/delSetting',3,'',2,0,0),(25,20,'删除文件','','/admin/setting/delFile',3,'',1,0,0);
/*!40000 ALTER TABLE `hhkj_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hhkj_role`
--

DROP TABLE IF EXISTS `hhkj_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hhkj_role` (
  `role_id` int(10) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(20) NOT NULL,
  `ids` text NOT NULL,
  `describe` varchar(255) NOT NULL,
  `atime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='管理员角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hhkj_role`
--

LOCK TABLES `hhkj_role` WRITE;
/*!40000 ALTER TABLE `hhkj_role` DISABLE KEYS */;
INSERT INTO `hhkj_role` VALUES (1,'超级管理员','[9,10,11,2,6,12,13,5,14,1,16,17,18,19,15,25,20,22,24,23,21,7]','最高权限','2019-03-22 21:53:27'),(12,'测试角色','[9,10,11,2,6,12,13,5,14,1,16,17,18,19,15,25,20,22,24,23,21,7]','111','2022-03-21 17:35:11');
/*!40000 ALTER TABLE `hhkj_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hhkj_setting`
--

DROP TABLE IF EXISTS `hhkj_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hhkj_setting` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` char(64) DEFAULT NULL COMMENT '配置标题',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 文本  2图片  ',
  `value` text NOT NULL,
  `canDel` tinyint(1) DEFAULT '1' COMMENT '是否允许删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='系统设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hhkj_setting`
--

LOCK TABLES `hhkj_setting` WRITE;
/*!40000 ALTER TABLE `hhkj_setting` DISABLE KEYS */;
INSERT INTO `hhkj_setting` VALUES (1,'系统名称',1,'鸿鹄科技管理后台',0);
/*!40000 ALTER TABLE `hhkj_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hhkj_upload_files`
--

DROP TABLE IF EXISTS `hhkj_upload_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hhkj_upload_files` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `domain` tinyint(1) DEFAULT '0' COMMENT '文件保存在哪里的 0虚拟文件夹 1七牛 2阿里oss 3腾讯cos',
  `type` tinyint(1) DEFAULT NULL COMMENT '文件类型  1图片 2视频 3 Excel 4 word 5 pdf 6 zip 7 未知类型文件 8文件夹',
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '文件名称',
  `key` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '上传到第三方的key',
  `url` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '文件地址',
  `atime` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `pid` int(11) DEFAULT '0' COMMENT '上级目录ID 顶级目录为0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hhkj_upload_files`
--

LOCK TABLES `hhkj_upload_files` WRITE;
/*!40000 ALTER TABLE `hhkj_upload_files` DISABLE KEYS */;
INSERT INTO `hhkj_upload_files` VALUES (2,1,1,'图层 11 拷贝@2x.png','16447502488861.png','https://qiniu.honghukeji.net//16447502488861.png','2022-02-13 18:57:11',0),(3,1,6,'TencentQQAuthCA.crt.zip','16447508494271.zip','https://qiniu.honghukeji.net//16447508494271.zip','2022-02-13 19:00:39',0),(17,3,1,'菜狗.gif','16449767693071.gif','https://hhkj-1259388795.cos.ap-chongqing.myqcloud.com//16449767693071.gif','2022-02-16 09:43:46',0),(27,3,1,'用户头像.png','16449777187091.png','https://hhkj-1259388795.cos.ap-chongqing.myqcloud.com//16449777187091.png','2022-02-16 10:02:59',0),(28,3,1,'用户头像2.png','16449780286081.png','https://hhkj-1259388795.cos.ap-chongqing.myqcloud.com//16449780286081.png','2022-02-16 10:04:40',0),(30,4,1,'1703733271784.png','update/17045536032926884471.png','https://ecshop.honghukeji.net:10443/uploads/1703733271784.png',NULL,0);
/*!40000 ALTER TABLE `hhkj_upload_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hhkj_upload_set`
--

DROP TABLE IF EXISTS `hhkj_upload_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hhkj_upload_set` (
  `id` int(10) NOT NULL,
  `qiniu` text,
  `alioss` text,
  `txcos` text,
  `visible` tinyint(1) NOT NULL COMMENT '选用的哪个 0未选用 1七牛 2阿里 3腾讯',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hhkj_upload_set`
--

LOCK TABLES `hhkj_upload_set` WRITE;
/*!40000 ALTER TABLE `hhkj_upload_set` DISABLE KEYS */;
INSERT INTO `hhkj_upload_set` VALUES (1,'{\"ak\":\"123\",\"bucket\":\"hhzz001\",\"domain\":\"https://qiniu.honghukeji.net\",\"sk\":\"456\",\"visible\":1}','{\"ak\":\"111\",\"bucket\":\"honghukeji\",\"domain\":\"https://honghukeji.oss-cn-beijing.aliyuncs.com/\",\"endpoint\":\"oss-cn-beijing.aliyuncs.com\",\"sk\":\"111\",\"visible\":4}','{\"ak\":\"111\",\"bucket\":\"ap-chongqing\",\"bucketName\":\"hhkj-1259388795\",\"domain\":\"https://hhkj-1259388795.cos.ap-chongqing.myqcloud.com/\",\"sk\":\"2222\",\"visible\":4}',1);
/*!40000 ALTER TABLE `hhkj_upload_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'jichu'
--

--
-- Dumping routines for database 'jichu'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-31 14:29:53
